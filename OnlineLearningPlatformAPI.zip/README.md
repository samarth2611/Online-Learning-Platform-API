# Online Learning Platform API
Spring Boot + MongoDB backend project skeleton.