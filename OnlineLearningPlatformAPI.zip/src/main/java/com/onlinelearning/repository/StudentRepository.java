package com.onlinelearning.repository;
import com.onlinelearning.model.Student;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface StudentRepository extends MongoRepository<Student,String>{}