package com.onlinelearning.model;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="students")
public class Student {
 @Id
 private String studentId;
 private String name;
 private String email;
}